﻿using Contactstry.DbClass;
using Contactstry.Models;
using Contactstry.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Contactstry.RepoImplementation
{
    public class ContactsDbIm : IContacts
    {
        private ContactsDb _dbobj;
        public ContactsDbIm(ContactsDb dbobj)
        {
            _dbobj = dbobj;
        }
        public bool CreateContact(Contacts obj)
        {
            _dbobj.Contacts.Add(obj);
            return Save();
        }

       

        public ICollection<Contacts> GetContacts()
        {
            return _dbobj.Contacts.OrderBy(a => a.ContactId).Where(a=>a.IsActive=="Active").ToList();
        }

        public bool Save()
        {
            return _dbobj.SaveChanges() >= 0 ? true : false;
        }
        public Contacts DeleteContact(int contactID)
        {
            Contacts ajjj = _dbobj.Contacts.FirstOrDefault(a => a.ContactId == contactID);
            if (ajjj != null)
            {
              
                ajjj.IsActive = "InAcive";
                _dbobj.Contacts.Update(ajjj);
                _dbobj.SaveChanges();
            }
            else
            {
                //return ajjj;
            }
            return ajjj;

        }
        public Contacts UpdateContact(Contacts conts)
        {
            Contacts ajjj = _dbobj.Contacts.FirstOrDefault(a => a.ContactId == conts.ContactId);
            if (ajjj != null)
            {
                ajjj.Name = conts.Name;
                ajjj.EmailID = conts.EmailID;
                ajjj.TelephoneNo = conts.TelephoneNo;
                ajjj.Photograph = conts.Photograph;
                ajjj.Birthday = conts.Birthday;
                ajjj.MarriageAnniversary = conts.MarriageAnniversary;
                _dbobj.Contacts.Update(ajjj);
                _dbobj.SaveChanges();
            }
            else
            {
               
            }
            return ajjj;
        }

        public Contacts GetContByName(string name)
        {
           Contacts aj=  _dbobj.Contacts.FirstOrDefault(a => a.Name == name);
            return aj;

        }
    }
}
