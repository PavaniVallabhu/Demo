﻿using Contactstry.Models;
using Contactstry.RepoImplementation;
using Contactstry.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Contactstry.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactsController : ControllerBase
    {
        //ContactsDbIm obj = new ContactsDbIm();
        public IContacts _contacts;
        public ContactsController(IContacts contacts)
        {
            _contacts = contacts;
        }
        [HttpGet]
        public IActionResult GetContacts()
        {
            //      List<Contacts> listobj = new List<Contacts>();

            return Ok(_contacts.GetContacts());
        }
       [HttpGet("{Name}")]
        public IActionResult GetContactsByName(string name)
        {
            return Ok(_contacts.GetContByName( name));

        }




        [HttpPost]
        public IActionResult CreateContact([FromBody] Contacts contactobj)
        {
            bool aj = _contacts.CreateContact(contactobj);
            if (aj)
                return StatusCode(200);
            else
            {
                return StatusCode(400);
            }
        }
        [HttpPut]
        public IActionResult UpdateContact(Contacts conts)
        {
            Contacts aj = _contacts.UpdateContact(conts);
            if (aj != null)
                return StatusCode(200);
            else
            {
                return StatusCode(202);
            }
        }
        [HttpDelete("{contactId}")]
        public IActionResult DeleteContact(int contactId)
        {
            Contacts ajj = _contacts.DeleteContact(contactId);
            if (ajj != null)
            {
                return StatusCode(200);
            }
            else
            {
                return StatusCode(500);
            }
        }

    

      
    }
}


  

