﻿using Contactstry.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Contactstry.DbClass
{
    public class ContactsDb:DbContext
    {
        public ContactsDb(DbContextOptions options) : base(options)
        {

        }
        public DbSet<Contacts> Contacts { get; set; }

      
    }
}
