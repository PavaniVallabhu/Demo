﻿using Contactstry.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Contactstry.Repository
{
    public interface IContacts
    {
        ICollection<Contacts> GetContacts();
        bool CreateContact(Contacts obj);
        Contacts UpdateContact(Contacts conts);

        Contacts DeleteContact(int contactID);

        Contacts GetContByName(string name);

    }
}
