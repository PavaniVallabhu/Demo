﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Contactstry.Models
{
    [Table("Contacts")]
    public class Contacts
    {
        [Key]
        public int ContactId { get; set; }
        public string Name { get; set; }
        public string EmailID { get; set; }
        public string Photograph { get; set; }
        public string Birthday { get; set; }
        public string MarriageAnniversary { get; set; }
        public string TelephoneNo { get; set; }

        public string IsActive { get; set; }

    }
}
