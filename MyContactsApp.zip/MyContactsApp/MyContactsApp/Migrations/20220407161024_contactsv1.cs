﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace MyContactsApp.Migrations
{
    public partial class contactsv1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
