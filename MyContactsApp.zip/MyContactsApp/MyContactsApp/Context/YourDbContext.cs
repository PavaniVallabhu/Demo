﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using MyContactsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyContactsApp.Context
{
    public class YourDbContext : DbContext
    {
        public YourDbContext(DbContextOptions options):base(options)
        {

        }
        public DbSet<Contacts> Contacts { get; set; }

    }

    public class YourDbContextFactory : IDesignTimeDbContextFactory<YourDbContext>
    {
        public YourDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<YourDbContext>();
            optionsBuilder.UseSqlServer("your connection string");

            return new YourDbContext(optionsBuilder.Options);
        }
    }
}
